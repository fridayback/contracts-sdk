

const groupInfoTokenPlutus = require('./groupNFT.json');
const groupInfoTokenHolderPlutus = require('./groupNFT-holder.json');
const treasuryPlutus = require('./treasury.json');
const treasuryCheckPlutus = require('./treasury-check.json');
const mappingTokenPlutus = require('./mapping-token.json');
const mintCheckPlutus = require('./mint-check.json');

module.exports = {
    groupInfoTokenPlutus
    , groupInfoTokenHolderPlutus
    , treasuryPlutus
    , treasuryCheckPlutus
    , mappingTokenPlutus
    , mintCheckPlutus
}